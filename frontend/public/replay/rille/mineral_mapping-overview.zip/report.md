# AstroScan field-test report — Harrat Khaybar

Analysis `replay-rille` (replay)
Data `581212a492338986` · Model `1.1.1`

**Objective** Mineral mapping · Effective weights (slope 29%, roughness 29%, lighting 43%)

## Lunar traverse

Frame — Mean Earth / Polar Axis (DE421), planetocentric, east-positive
Traverse length 7.36 km · Direct 6.61 km
Ascent 284 m · Descent 316 m · Maximum grade 19.0°
Valid corridor 100.0% · Coverage confidence high
- A requested 26.190000°, 3.470000° → snapped 26.189429°, 3.470124° (18 m).
- B requested 26.120000°, 3.700000° → snapped 26.121348°, 3.698347° (61 m).

## Earth matches

- 1. **Harrat Khaybar** · 7.19 km · similarity 0.819 · slope 0.772 · roughness 0.842 · coverage 100.0% · coverage confidence high.
- 2. **Payún Matrú** · 7.09 km · similarity 0.765 · slope 0.838 · roughness 0.829 · coverage 100.0% · coverage confidence high.
- 3. **Pinacate** · 8.27 km · similarity 0.625 · slope 0.909 · roughness 0.679 · coverage 100.0% · coverage confidence high.

## Field test

Selected traverse runs from 25.649743°, 40.025694° to 25.602065°, 39.986749°. See the Earth route in the accompanying GeoJSON.
Record field spectra and sample location across mapped rock-unit boundaries.

## Illumination and test windows

Lunar scenario 2026-11-18T00:00:00Z · Sun 13.3° above the horizon · azimuth 98.5° · shadow 15.0% of evaluable route samples · coverage 100.0%.
Geometric solar elevation at the route midpoint and DEM terrain shadows sampled along the route. Horizon search extends to 12 km at 5° azimuth spacing. Terrain and shadows below DEM resolution, reflected light, atmosphere and weather can affect camera tests.
Earth search started 2026-11-14 UTC.
- 2026-11-18T23:40:00+03:00 to 2026-11-19T00:00:00+03:00 (Asia/Riyadh) · UTC 2026-11-19T04:40:00 to 2026-11-19T05:00:00 · best frame 2026-11-19T04:50:00, shadow 16.6% · coverage 100.0%.
- 2026-11-30T23:50:00+03:00 to 2026-12-01T00:10:00+03:00 (Asia/Riyadh) · UTC 2026-12-01T04:50:00 to 2026-12-01T05:10:00 · best frame 2026-12-01T05:00:00, shadow 16.6% · coverage 100.0%.
- 2026-11-29T23:50:00+03:00 to 2026-11-30T00:00:00+03:00 (Asia/Riyadh) · UTC 2026-11-30T04:50:00 to 2026-11-30T05:00:00 · best frame 2026-11-30T05:00:00, shadow 16.6% · coverage 100.0%.
- 2026-11-19T23:50:00+03:00 to 2026-11-20T00:00:00+03:00 (Asia/Riyadh) · UTC 2026-11-20T04:50:00 to 2026-11-20T05:00:00 · best frame 2026-11-20T04:50:00, shadow 16.6% · coverage 100.0%.
- 2026-12-13T00:00:00+03:00 to 2026-12-13T00:20:00+03:00 (Asia/Riyadh) · UTC 2026-12-13T05:00:00 to 2026-12-13T05:20:00 · best frame 2026-12-13T05:10:00, shadow 16.9% · coverage 100.0%.

## Mineral evidence and mapped geology

- Moon mapped units · Mare Unit (Em) 100.0% · coverage 100.0%.
- Moon oneMicron · median depth 9.5% · center 970 nm · 27 pixels · coverage 100.0%.
- Moon twoMicron · median depth 4.2% · center 2060 nm · 27 pixels · coverage 100.0%.
- Harrat Khaybar mapped units · Basic volcanic rocks 100.0% · coverage 100.0%.
- Harrat Khaybar spectra · Fewer than five distinct pixels or 70% route support for usable bands.
- Harrat Khaybar oneMicron · median depth 4.4% · center 930 nm · 9 pixels · coverage 34.6%.
Mapped units provide qualitative rock-type context. Spectral scoring requires shared calibrated bands across every eligible candidate.

## Limitations

- Elevation products resolve regional terrain at the analysis grid scale. Subpixel hazards and surface mechanics require separate evaluation.
- Earth and lunar elevations use different vertical references. Compare profiles relative to the start of each route.
- Terrain similarity describes slope and roughness. Gravity, atmosphere, radiation, dust and temperature differ between Earth and the Moon.
- Field access, weather, permits and on-site hazards require a separate review.

## Sources

- [SLDEM2015_512_00N_30N_000_045](https://pds-geosciences.wustl.edu/lro/lro-l-lola-3-rdr-v1/lrolol_1xxx/data/sldem2015/tiles/jp2/sldem2015_512_00n_30n_000_045_jp2.lbl) · V2.0 · NASA Planetary Data System public archive
- [copernicus-glo30-pinacate](https://copernicus-dem-30m.s3.amazonaws.com/readme.html) · GLO-30 Public, 2021 release · Copernicus DEM GLO-30 public license
- [copernicus-glo30-harrat-khaybar](https://copernicus-dem-30m.s3.amazonaws.com/readme.html) · GLO-30 Public, 2021 release · Copernicus DEM GLO-30 public license
- [copernicus-glo30-payun-matru](https://copernicus-dem-30m.s3.amazonaws.com/readme.html) · GLO-30 Public, 2021 release · Copernicus DEM GLO-30 public license
- [LRO_WAC_Mosaic_Global_303ppd_v02](https://trek.nasa.gov/moon/TrekWS/rest/cat/metadata/fgdc/html?label=LRO_WAC_Mosaic_Global_303ppd_v02) · 2 · NASA Moon Trek public dataset. Credit LROC team.
- [sentinel-2-pinacate](https://earth-search.aws.element84.com/v1/collections/sentinel-2-l2a/items/S2A_12STA_20241117_0_L2A) · L2A · Modified Copernicus Sentinel data 2024
- [sentinel-2-harrat-khaybar](https://earth-search.aws.element84.com/v1/collections/sentinel-2-l2a/items/S2A_37REJ_20241022_0_L2A) · L2A · Modified Copernicus Sentinel data 2024
- [sentinel-2-payun-matru](https://earth-search.aws.element84.com/v1/collections/sentinel-2-l2a/items/S2A_19HDV_20241026_0_L2A) · L2A · Modified Copernicus Sentinel data 2024
- [NAIF-DE440](https://naif.jpl.nasa.gov/naif/data_lunar.html) · DE440 / ME421 · NASA NAIF public archive
- [USGS-lunar-geology](https://astrogeology.usgs.gov/search/map/Moon/Geology/Unified_Geologic_Map_of_the_Moon_GIS_v2/) · 2020, 1:5M · USGS public data
- [GLiM](https://doi.org/10.1029/2012GC004370) · 1.1 · Hartmann and Moosdorf (2012)
- [M3-L2](https://doi.org/10.17189/1520414) · 1.0 · NASA PDS public archive
- [EMIT-L2A](https://cmr.earthdata.nasa.gov/search/concepts/C2408750690-LPCLOUD.html) · 001 · NASA Earthdata
- [pvlib-SPA](https://pvlib-python.readthedocs.io/en/stable/reference/generated/pvlib.solarposition.get_solarposition.html) · 0.16.1 · BSD 3-Clause
