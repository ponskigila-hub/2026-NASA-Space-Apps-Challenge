# AstroScan field-test report — Payún Matrú

Analysis `replay-hadley` (replay)
Data `581212a492338986` · Model `1.1.1`

**Objective** Rover navigation · Effective weights (slope 37%, roughness 37%, lighting 26%)

## Lunar traverse

Frame — Mean Earth / Polar Axis (DE421), planetocentric, east-positive
Traverse length 39.74 km · Direct 36.21 km
Ascent 3102 m · Descent 342 m · Maximum grade 19.9°
Valid corridor 100.0% · Coverage confidence high
- A requested 26.143017°, 3.079142° → snapped 26.143763°, 3.080072° (34 m).
- B requested 26.357301°, 4.389023° → snapped 26.357139°, 4.390627° (44 m).

## Earth matches

- 1. **Payún Matrú** · 40.05 km · similarity 0.565 · slope 0.605 · roughness 0.886 · coverage 100.0% · coverage confidence high.
- 2. **Pinacate** · 40.14 km · similarity 0.492 · slope 0.558 · roughness 0.741 · coverage 100.0% · coverage confidence high.
- 3. **Harrat Khaybar** · 36.89 km · similarity 0.461 · slope 0.538 · roughness 0.679 · coverage 100.0% · coverage confidence high.

## Field test

Selected traverse runs from -36.353139°, -69.241797° to -36.250284°, -69.633163°. See the Earth route in the accompanying GeoJSON.
Measure traction and camera-based navigation performance across resolved grades.

## Illumination and test windows

Lunar scenario 2026-11-18T00:00:00Z · Sun 13.4° above the horizon · azimuth 98.6° · shadow 30.4% of evaluable route samples · coverage 100.0%.
Geometric solar elevation at the route midpoint and DEM terrain shadows sampled along the route. Horizon search extends to 12 km at 5° azimuth spacing. Terrain and shadows below DEM resolution, reflected light, atmosphere and weather can affect camera tests.
Earth search started 2026-11-14 UTC.
No daytime window met both the 2° Sun elevation and 10-point shadow tolerances.

## Mineral evidence and mapped geology

- Moon mapped units · Mare Unit (Em) 64.6%, Basin Massif Unit (Nbm) 35.4% · coverage 100.0%.
- Moon oneMicron · median depth 7.7% · center 950 nm · 138 pixels · coverage 97.2%.
- Moon twoMicron · median depth 3.9% · center 2020 nm · 142 pixels · coverage 100.0%.
- Payún Matrú mapped units · Basic volcanic rocks 43.2%, Acid volcanic rocks 31.6%, Siliciclastic sedimentary rocks 13.9%, Carbonate sedimentary rocks 11.3% · coverage 100.0%.
- Payún Matrú spectra · EMIT reflectance and quality masks must be prepared from an Earthdata scene for this region.
Mapped units provide qualitative rock-type context. Spectral scoring requires shared calibrated bands across every eligible candidate.

## Limitations

- Elevation products resolve regional terrain at the analysis grid scale. Subpixel hazards and surface mechanics require separate evaluation.
- Earth and lunar elevations use different vertical references. Compare profiles relative to the start of each route.
- Terrain similarity describes slope and roughness. Gravity, atmosphere, radiation, dust and temperature differ between Earth and the Moon.
- Field access, weather, permits and on-site hazards require a separate review.

## Sources

- [SLDEM2015_512_00N_30N_000_045](https://pds-geosciences.wustl.edu/lro/lro-l-lola-3-rdr-v1/lrolol_1xxx/data/sldem2015/tiles/jp2/sldem2015_512_00n_30n_000_045_jp2.lbl) · V2.0 · NASA Planetary Data System public archive
- [copernicus-glo30-pinacate](https://copernicus-dem-30m.s3.amazonaws.com/readme.html) · GLO-30 Public, 2021 release · Copernicus DEM GLO-30 public license
- [copernicus-glo30-harrat-khaybar](https://copernicus-dem-30m.s3.amazonaws.com/readme.html) · GLO-30 Public, 2021 release · Copernicus DEM GLO-30 public license
- [copernicus-glo30-payun-matru](https://copernicus-dem-30m.s3.amazonaws.com/readme.html) · GLO-30 Public, 2021 release · Copernicus DEM GLO-30 public license
- [LRO_WAC_Mosaic_Global_303ppd_v02](https://trek.nasa.gov/moon/TrekWS/rest/cat/metadata/fgdc/html?label=LRO_WAC_Mosaic_Global_303ppd_v02) · 2 · NASA Moon Trek public dataset. Credit LROC team.
- [sentinel-2-pinacate](https://earth-search.aws.element84.com/v1/collections/sentinel-2-l2a/items/S2A_12STA_20241117_0_L2A) · L2A · Modified Copernicus Sentinel data 2024
- [sentinel-2-harrat-khaybar](https://earth-search.aws.element84.com/v1/collections/sentinel-2-l2a/items/S2A_37REJ_20241022_0_L2A) · L2A · Modified Copernicus Sentinel data 2024
- [sentinel-2-payun-matru](https://earth-search.aws.element84.com/v1/collections/sentinel-2-l2a/items/S2A_19HDV_20241026_0_L2A) · L2A · Modified Copernicus Sentinel data 2024
- [NAIF-DE440](https://naif.jpl.nasa.gov/naif/data_lunar.html) · DE440 / ME421 · NASA NAIF public archive
- [USGS-lunar-geology](https://astrogeology.usgs.gov/search/map/Moon/Geology/Unified_Geologic_Map_of_the_Moon_GIS_v2/) · 2020, 1:5M · USGS public data
- [GLiM](https://doi.org/10.1029/2012GC004370) · 1.1 · Hartmann and Moosdorf (2012)
- [M3-L2](https://doi.org/10.17189/1520414) · 1.0 · NASA PDS public archive
- [EMIT-L2A](https://cmr.earthdata.nasa.gov/search/concepts/C2408750690-LPCLOUD.html) · 001 · NASA Earthdata
- [pvlib-SPA](https://pvlib-python.readthedocs.io/en/stable/reference/generated/pvlib.solarposition.get_solarposition.html) · 0.16.1 · BSD 3-Clause
